sudo apt-get update && sudo apt-get upgrade && sudo apt-get dist-upgrade
wget https://dl.google.com/go/go1.14.1.linux-amd64.tar.gz
tar -C /usr/local -xzf go1.14.1.linux-amd64.tar.gz
export GOPATH=$HOME/go
export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin
source /root/.profile


rm -rf vendor;go mod tidy;go mod vendor;make

Failed to start nameserver on: :53
sudo systemctl stop systemd-resolved

listen tcp :443: bind: address already in use
systemctl stop apache2
systemctl stop nginx

sudo systemctl disable systemd-resolved

sudo systemctl stop nsd
sudo systemctl disable nsd
sudo kill $(sudo lsof -t -i :443)


###evilginx2 gui####
go get -u github.com/go-sql-driver/mysql

"""
CREATE DATABASE evilginx;
USE evilginx;

CREATE TABLE sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_name VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""


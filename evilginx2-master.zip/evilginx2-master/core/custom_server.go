package main

import (
    "encoding/json"
    "log"
    "net/http"
)



// Session represents a session object
type Session struct {
    ID   string `json:"id"`
    Data string `json:"data"`
}

// In-memory store for sessions
var sessions = []Session{}

// Handler to retrieve sessions
func handleGetSessions(w http.ResponseWriter, r *http.Request) {
    // Set the content type to JSON
    w.Header().Set("Content-Type", "application/json")
    
    // Encode the sessions slice to JSON and send it in the response
    if err := json.NewEncoder(w).Encode(sessions); err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
    }
}

// Handler to create a new session
func handleCreateSession(w http.ResponseWriter, r *http.Request) {
    // Only allow POST requests
    if r.Method != http.MethodPost {
        http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
        return
    }
    
    var newSession Session
    // Decode the JSON body into a Session object
    if err := json.NewDecoder(r.Body).Decode(&newSession); err != nil {
        http.Error(w, err.Error(), http.StatusBadRequest)
        return
    }
    
    // Add the new session to the in-memory store
    sessions = append(sessions, newSession)
    
    // Respond with the created session
    w.Header().Set("Content-Type", "application/json")
    w.WriteHeader(http.StatusCreated)
    if err := json.NewEncoder(w).Encode(newSession); err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
    }
}

func handler(w http.ResponseWriter, r *http.Request) {
    // Respond with a simple message
    w.Write([]byte("Hello, World!"))
}

func main() {
    // Define your routes and associate them with the handler functions
	http.HandleFunc("/", handler)
    http.HandleFunc("/sessions", handleGetSessions)         // GET request to retrieve sessions
    http.HandleFunc("/sessions/create", handleCreateSession) // POST request to create a session

    // Start the server
    log.Println("Starting server on :8080")
    if err := http.ListenAndServe(":8080", nil); err != nil {
        log.Fatal(err)
    }
}




